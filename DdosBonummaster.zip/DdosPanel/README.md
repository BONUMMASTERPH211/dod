<div align=center>
 
# 🚀 Dandier DDoS Panel 🚀

<p>
 <img src="https://img.shields.io/github/stars/hoaan1995/ZxCDDoS?color=%23DF0067&style=for-the-badge"/> &nbsp;
 <img src="https://img.shields.io/github/forks/hoaan1995/ZxCDDoS?color=%239999FF&style=for-the-badge"/> &nbsp;
 <img src="https://img.shields.io/github/license/hoaan1995/ZxCDDoS?color=%23E8E8E8&style=for-the-badge"/> &nbsp;
 
</p>

<p align="center">  <a href="https://t.me/mrd4nd"><img width="160" height="50" src="https://i.imgur.com/N7AK7XY.png"></a></p>
 
## Language</br>

 <img src="https://img.shields.io/badge/Python-FFDD00?style=for-the-badge&logo=python&logoColor=blue"/> <img src="https://img.shields.io/badge/JavaScript-323330?style=for-the-badge&logo=javascript&logoColor=F7DF1E"/> <img src="https://img.shields.io/badge/Go-00ADD8?style=for-the-badge&logo=go&logoColor=white"/>
 </div>
 
 ## Logs</br>
 - POWERFUL L7!
 - DONT RESELL THIS TOOLS!
 - OPEN SOURCE!!
   
# Tree
* [𝕀𝕟𝕗𝕠](#Info)
* [𝕊𝕖𝕥𝕦𝕡](#Setup)
* [ℂ𝕣𝕖𝕕𝕚𝕥𝕤](#Credits)
* [ℙ𝕠𝕨𝕖𝕣](#Power)
* [ℝ𝕦𝕝𝕖𝕤](#TOS)
* [𝕒𝕡𝕡𝕖𝕒𝕣𝕒𝕟𝕔𝕖](#Appearance)
* [ℂ𝕠𝕟𝕥𝕒𝕔𝕥](#Contact)

# README ♥️
Thank you for using, please help me press a star button, thank you very much.<br>
One star = continuously updating multiple methods

# Info
- [x] Premium
- [x] Powerful
- [x] Simple
- [x] Open Source
- [x] Methods for L7

# Setup
```sh
How to use: 
- Recommended in shell of google...
- Using vps with high speed will be stronger

npm i cloudscraper
npm i fs
npm i hcaptcha-solver
npm i https-proxy-agent
npm i cloudflare-bypasser
npm i http http2 crypto tls
npm i net
git clone https://github.com/dandiers/DdosPanel.git
cd DdosPanel
pip install -r requirements.txt
python3 main.py
```

# Credits
```sh
dandier (Owner Of This Tools.-.)
```

# Appearance
<img  src="https://github.com/dandiers/ddospanel/assets/61583533/dd7db5a0-320c-4759-8d92-d75dd3fd9ce6"></img>


# Power
<img src="https://github.com/dandiers/ddospanel/assets/61583533/09e36550-8f83-44bd-ab4f-345bd8236d93"></img>


<img src="https://github.com/dandiers/ddospanel/assets/61583533/591a8254-e881-4c29-8b12-021df28dd2f2"></img>
# Rules:
```sh
Do not attack government pages (.gov/.gob), educational pages (.edu) or the United States Department of Defense (.mil), 
the creator is not responsible for the damage caused by the attacks. 
remember: you are responsible for the attacks since this tool was created for educational purposes
```

# CONTACT:
```sh
Telegram: @mrd4nd
Discord: dandier#1121
```
